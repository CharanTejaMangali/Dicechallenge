// First dice
var randomNumber1 = Math.floor(Math.random() * 6) + 1; //1-6 numbers

var randomImage1 = "dice" + randomNumber1 + ".png" ;  //didce1.png

var randomSource1 = "images/" + randomImage1; //for creating random img src

var image1 = document.querySelectorAll("img")[0];
image1.setAttribute("src",randomSource1);

// SECOND DICE

var randomNumber2 = Math.floor(Math.random() * 6) + 1;

var randomSource2 = "images/dice" + randomNumber2 + ".png";

var image2 = document.querySelectorAll("img")[1].setAttribute("src",randomSource2);

if (randomNumber1 > randomNumber2) {
    document.querySelector("h1").innerHTML = "🚩 Player 1 wins";
}else if(randomNumber1 === randomNumber2) {
    document.querySelector("h1").innerHTML = "It's a tie!";
}
else {
    document.querySelector("h1").innerHTML = "Player 2 wins 🚩";
}





